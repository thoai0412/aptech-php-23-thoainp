<?php

namespace Miracuthbert\Royalty\Exceptions;

use Exception;

class PointModelMissingException extends Exception
{
    //
}
