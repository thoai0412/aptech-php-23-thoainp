<?php

namespace Miracuthbert\Royalty;

class Royalty
{
    const ROYALTY_CONFIG = 'royalty-config';
    const ROYALTY_MIGRATIONS = 'royalty-migrations';
    const ROYALTY_COMPONENTS = 'royalty-components';
}
